using Microsoft.Extensions.Configuration;
using System.Net;
using System.Net.Mail;

namespace Krea.Infrastructure.Services;

using Application.Abstractions.Email;

public class EmailService : IEmailService
{
    private readonly IConfiguration _configuration;

    public EmailService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public async Task SendConfirmationEmailAsync(string email, string userName, string confirmationLink)
    {
        var smtpHost = _configuration["Email:SmtpHost"];
        var smtpPort = int.Parse(_configuration["Email:SmtpPort"]!);
        var smtpUser = _configuration["Email:SmtpUser"];
        var smtpPass = _configuration["Email:SmtpPassword"];
        var fromAddress = _configuration["Email:FromAddress"];

        using var client = new SmtpClient(smtpHost, smtpPort);
        client.Credentials = new NetworkCredential(smtpUser, smtpPass);
        client.EnableSsl = true;

        var mailMessage = new MailMessage
        {
            From = new MailAddress(fromAddress ?? throw new InvalidOperationException()),
            Subject = "Confirm your email",
            Body = $@"
                <h1>Welcome, {userName}!</h1>
                <p>Please confirm your email by clicking the link below:</p>
                <a href='{confirmationLink}'>Confirm Email</a>
                <p>If you did not register, ignore this email.</p>",
            IsBodyHtml = true
        };
        mailMessage.To.Add(email);

        await client.SendMailAsync(mailMessage);
    }
}