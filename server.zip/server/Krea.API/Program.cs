namespace Krea.API {
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.IdentityModel.Tokens;
    using Scalar.AspNetCore;
    using System.Text;
    using Infrastructure;
    using Application;
    using Application.Abstractions.Url;
    using Hubs;
    using Infrastructure.Configuration;
    using Infrastructure.Setup;
    using Microsoft.Extensions.Primitives;
    using Services;

    internal static class Program {
        public static async Task Main(string[] args) {
            WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

            builder.Services.AddApplication();
            builder.Services.AddControllers();
            builder.Services.AddSignalR();
            builder.Services.AddOpenApi();
            builder.Services.AddCors(options => {
                options.AddPolicy("AllowFrontend", policy => {
                    policy.WithOrigins("http://localhost:5173", "http://127.0.0.1:5173")
                          .AllowAnyMethod()
                          .AllowAnyHeader()
                          .AllowCredentials();
                });
            });


            // Agregar infraestructura (DbContext, Identity, repositorios, servicios)
            builder.Services.AddInfrastructure(builder.Configuration);

            // Configurar autenticación JWT
            builder.Services.AddAuthentication(options => {
                       options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                       options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                   })
                   .AddJwtBearer(options => {
                       options.TokenValidationParameters = new TokenValidationParameters {
                           ValidateIssuer = true,
                           ValidateAudience = true,
                           ValidateLifetime = true,
                           ValidateIssuerSigningKey = true,
                           ValidIssuer = builder.Configuration["Jwt:Issuer"],
                           ValidAudience = builder.Configuration["Jwt:Audience"],
                           IssuerSigningKey = new SymmetricSecurityKey(
                               Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
                       };
                       // Accept token in query string
                       options.Events = new JwtBearerEvents {
                           OnMessageReceived = context => {
                               StringValues accessToken = context.Request.Query["access_token"];
                               PathString path = context.HttpContext.Request.Path;
                               if (!string.IsNullOrEmpty(accessToken) && path.StartsWithSegments("/hubs")) {
                                   context.Token = accessToken;
                               }

                               return Task.CompletedTask;
                           }
                       };
                   });

            builder.Services.AddAuthorization();

            builder.Services.AddHttpContextAccessor();
            builder.Services.AddScoped<IConfirmationUrlBuilder, ConfirmationUrlBuilder>();

            // Seeding configs
            builder.Services.Configure<AdminUserOptions>(builder.Configuration.GetSection("AdminUser"));
            builder.Services.Configure<SeedingOptions>(builder.Configuration.GetSection("Seeding"));

            WebApplication app = builder.Build();

            using (IServiceScope scope = app.Services.CreateScope()) {
                await DatabaseInitializer.InitializeAsync(scope.ServiceProvider);
            }

            if (app.Environment.IsDevelopment()) {
                app.MapOpenApi();
                app.MapScalarApiReference(options => {
                    options
                        .WithTitle("Krea API")
                        .WithTheme(ScalarTheme.Purple)
                        .WithDefaultHttpClient(ScalarTarget.CSharp, ScalarClient.HttpClient);
                });
            }

            app.UseHttpsRedirection();
            app.UseCors("AllowFrontend");
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseStaticFiles();
            app.MapControllers();

            app.MapHub<DirectMessageHub>("/hubs/directmessage");

            await app.RunAsync();
        }
    }
}